import { Component } from '@angular/core';
import { AuthComponent } from './pages/auth/auth';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [AuthComponent],
  templateUrl: './app.html'
})
export class AppComponent {}