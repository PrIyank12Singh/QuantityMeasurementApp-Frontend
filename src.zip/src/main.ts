import { bootstrapApplication } from '@angular/platform-browser';
import { provideHttpClient } from '@angular/common/http';
import { AuthComponent } from './app/pages/auth/auth';

bootstrapApplication(AuthComponent, {
  providers: [
    provideHttpClient()
  ]
}).catch(err => console.error(err));