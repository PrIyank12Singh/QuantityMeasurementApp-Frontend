export const environment = {
  production: true,
  apiUrl: 'https://apigateway-jl2d.onrender.com',
  authUrl: 'https://authenticationservice-h3hj.onrender.com',
  quantityUrl: 'https://quantityservice-rb06.onrender.com'
};
